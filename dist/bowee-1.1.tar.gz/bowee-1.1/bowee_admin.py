#!/usr/bin/env python

import bowee.bowee

bowee.bowee.main()
